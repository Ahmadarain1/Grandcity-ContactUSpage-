/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "var(--background)",
        foreground: "var(--foreground)",
        'white-60': 'rgba(255, 255, 255, 0.6)', // Replace with actual color value
        'light-silver': '#d3d3d3',
      },
      fontFamily: {
        raleway: ['"Raleway"', 'sans-serif'], // Add a fallback if Raleway fails to load
        'heading': ['Your Custom Font', 'sans-serif'],
      },
      transform: {
        'translate-x-33.8816': 'translateX(33.8816%)',
      },
    },
  },
  plugins: [],
};
