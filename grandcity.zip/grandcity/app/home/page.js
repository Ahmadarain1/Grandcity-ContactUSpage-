import React from 'react'
import "./custom.css";
import Image from "next/image";
import Link from 'next/link';
import ContactInfo from '@/components/Contact/ContactInfo';
import AboutBanner from '@/components/About/AboutBanner';


const page = () => {
  return (
    <div className='font-raleway not-italic m-0  text-base font-normal leading-normal text-gray-900 text-left bg-white text-size-adjust-100 tap-highlight-transparent'>
      {/*Header*/}
    
    
    {/*Hero Section*/}
    <div className='opacity-100 transform-none'>
        <main className='block isolate'>
            {/*Section 1*/}
            <section className='relative isolate h-[80vh] w-full bg-top bg-no-repeat bg-cover flex justify-center items-end overflow-hidden custom-background'>
                <div className='absolute inset-0 z-0 custom-gradient'></div>
                <div className='w-full pb-12 mb-12 mx-auto custom-padding'>
                    <div className='flex flex-wrap custom-margins'>
                        <div className='text-center flex-none w-full p-5'>
                            {/*main Heading*/}
                            <div className='opacity-100'>
                                <h1 className='opacity-100 transform-none text-9xl font-medium text-start text-[#fcfcfc] leading-[1.2]  block m-0 ml-0 mr-0 unicode-bidi-isolate custom-font'>Contact Us</h1>
                            </div>
                            {/*main title*/}
                            <div className='mt-2.5 block unicode-bidi-isolate'>
                                <div className='opacity-100 block unicode-bidi-isolate'>
                                    <h5 className='opacity-100 transform-none text-xl font-light text-start text-[#ffffffcc] m-0  leading-[1.2] block mb-[1.67em] mt-[1.67em] unicode-bidi-isolate'>Elevating Experiences, Fulfilling Dreams: Explore Our Comprehensive Services.</h5>
                                </div>
                            </div>
                             {/* Breadcrumbs */}
                            <div className="text-md text-start text-gray-400">
                                <Link href="/" className="hover:underline">
                                Home
                                </Link> 
                                &gt; 
                                <Link href="/contactus" className="hover:underline">
                                Contact Us
                                </Link>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='absolute bottom-0 left-0 right-0 w-screen h-[200px] z-1 custom-gradient2'></div>
            </section>
            {/*Section 2*/}
            <section className='relative overflow-hidden bg-black block isolate important-styles' id='offices'>
                <div className='w-full mx-auto max-w-[1313px] pt-[100px] pb-[100px] px-[20px]'>

                    {/*Heading*/}
                    <div className='mb-0 flex flex-wrap items-center justify-between -mt-[calc(-1*var(--bs-gutter-y))] -mr-[calc(-.5*var(--bs-gutter-x))] -ml-[calc(-.5*var(--bs-gutter-x))]'>
                        <div className='flex-none w-[41.66666667%] block bidi-isolate'>
                            <div className='opacity-100 '>
                                <h2 className='opacity-100 transform-none text-[45px] font-light text-[#ffffffcc] leading-[1.2]  block m-0 ml-0 mr-0 unicode-bidi-isolate custom-font'>Our locations</h2>
                            </div>
                            <div className='mt-4 block bidi-isolate '>
                                <div className='opacity-100'>
                                    <h5 className='opacity-100 transform-none text-xl font-light text-white-60 m-0 text-inherit leading-[1.2] block mb-[1.67em] mt-[1.67em] unicode-bidi-isolate '>
                                    We provide fast, secure and reliable services to our customers in 51 cities across the country through dedicated and highly experienced professionals.
                                    </h5>
                                </div>
                            </div>
                        </div>
                        {/*image*/}
                        <div className='block !flex-none w-5/12 isolate'>
                            <div className='block isolate transform translate-x-[20%] translate-z-0'>
                            <img src="/shape-bg.804a0d96.svg" alt="Shape Bg" className="text-transparent opacity-25 max-w-full h-auto align-middle overflow-clip" />
                            </div>
                        </div>
                    </div>
                
                    {/*Boxes*/}
                    <div className='w-full grid grid-cols-1  lg:grid-cols-3 gap-y-12 gap-x-8 auto-cols-fr '>    
                        {/*Box1*/}
                        <div className=' w-[403px] h-[317px] opacity-100 transform-none gap-x-[7.5em] gap-y-16 justify-around items-center p-16 px-[3.5em] flex relative transition-all duration-500 ease-in-out hover:bg-[#100f0fde] '>
                        {/*Des*/}
                        <div className='Description space-y-3'>
                            <div className='loc'>
                                <div className='opacity-100 block isolate'>
                                    <h5 className='opacity-100 transform-none text-[22px] font-light text-[#ffffffcc] m-0  leading-tight  block  isolate'>Grand City Head Office</h5>
                                </div>
                            </div>
                            <div className='address'>
                            <p className='opacity-100 transform-none text-[18px] leading-inherit text-white/60  font-light block  isolate'>DHA Phase-6 Sector C, 170 Street 4 Lahore, Pakistan</p>
                            </div>
                            <div className='timming'>
                            <p className='opacity-100 transform-none text-[18px] leading-inherit text-white/60 font-light block isolate'>MON-FRI: 9:00 AM - 6:00 PM</p>
                            </div>
                            <div className='emailNum'>
                                <a href='mailto:sales@pearlresidencia.com.pk' className='text-decoration-none text-[rgba(var(--bs-link-color-rgb),var(--bs-link-opacity,1))] cursor-pointer'>
                                <p className='opacity-100 transform-none text-sm leading-normal text-white/60 font-light block mb-2'>info@grandcity.pk</p>
                                </a>
                                <a href='tel:+92-304-111-2117' className='text-decoration-none text-[rgba(var(--bs-link-color-rgb),var(--bs-link-opacity,1))] cursor-pointer'>
                                <p className='opacity-100 transform-none text-sm leading-normal text-white/60 font-light block'>0335-111-11-55</p>
                                </a>
                            </div>
                         </div>
                         {/*border Style*/}
                            <div className='border border-[#f1d04033] transition-colors duration-200 z-1 absolute inset-0 block'>
                                <div className='z-[10] mt-[-1px] ml-[-1px] absolute top-0 left-0 right-auto bottom-auto block bidi-isolate'>
                                    <div className='w-[5em] h-px bg-[#d9b751] absolute top-0 left-0 right-auto bottom-auto overflow-visible block bidi-isolate'></div>
                                    <div className='w-px h-[5em] bg-[#d9b751] absolute top-0 left-0 right-auto bottom-auto overflow-visible'></div>
                                </div>
                                <div className='z-10 mb-[-1px] mr-[-1px] absolute bottom-0 right-0 top-auto left-auto block'>
                                    <div className='absolute top-auto bottom-0 left-auto right-0 w-[1px] h-[5em] bg-[#d9b751] overflow-visible block bidi-isolate'></div>
                                    <div className='absolute top-auto bottom-0 left-auto right-0 w-[5em] h-[1px] bg-[#d9b751] overflow-visible block bidi-isolate'></div>
                                </div>
                            </div>
                        </div>
                        {/*Box2*/}
                        <div className=' w-[403px] h-[317px] opacity-100 transform-none gap-x-[7.5em] gap-y-16 justify-around items-center p-16 px-[3.5em] flex relative transition-all duration-500 ease-in-out hover:bg-[#100f0fde] '>
                            {/*Des*/}
                            <div className='Description space-y-3'>
                            <div className='loc'>
                                <div className='opacity-100 block isolate'>
                                    <h5 className='opacity-100 transform-none text-[22px] font-light text-[#ffffffcc]  leading-tight  block  isolate'>Grand City Kharian Site Office</h5>
                                </div>
                            </div>
                            <div className='address'>
                            <p className='opacity-100 transform-none text-[18px] leading-inherit text-white/60  font-light block  isolate'>Main GT Road Kharian / Sarai Alamgir, Pakistan</p>
                            </div>
                            <div className='timming'>
                            <p className='opacity-100 transform-none text-[18px] leading-inherit text-white/60  font-light block  isolate'>MON-FRI: 9:00 AM - 6:00 PM</p>
                            </div>
                            <div className='emailNum '>
                                <a href='mailto:sales@pearlresidencia.com.pk' className='text-decoration-none text-[rgba(var(--bs-link-color-rgb),var(--bs-link-opacity,1))] cursor-pointer'>
                                <p className='opacity-100 transform-none text-sm leading-normal text-white/60  font-light block mb-2'>info@grandcity.pk</p>
                                </a>
                                <a href='tel:+92-304-111-2117' className='text-decoration-none text-[rgba(var(--bs-link-color-rgb),var(--bs-link-opacity,1))] cursor-pointer'>
                                <p className='opacity-100 transform-none text-sm leading-normal text-white/60   font-light block '>+92-42-111-115-511</p>
                                </a>
                            </div>
                            </div>
                            {/*border Style*/}
                            <div className='border border-[#f1d04033] transition-colors duration-200 z-1 absolute inset-0 block'>
                            <div className='z-[10] mt-[-1px] ml-[-1px] absolute top-0 left-0 right-auto bottom-auto block bidi-isolate'>
                                    <div className='w-[5em] h-px bg-[#d9b751] absolute top-0 left-0 right-auto bottom-auto overflow-visible block bidi-isolate'></div>
                                    <div className='w-px h-[5em] bg-[#d9b751] absolute top-0 left-0 right-auto bottom-auto overflow-visible'></div>
                                </div>
                                <div className='z-10 mb-[-1px] mr-[-1px] absolute bottom-0 right-0 top-auto left-auto block'>
                                    <div className='absolute top-auto bottom-0 left-auto right-0 w-[1px] h-[5em] bg-[#d9b751] overflow-visible block bidi-isolate'></div>
                                    <div className='absolute top-auto bottom-0 left-auto right-0 w-[5em] h-[1px] bg-[#d9b751] overflow-visible block bidi-isolate'></div>
                                </div>
                            </div>
                        </div>
                        {/*Box3*/}
                        <div className=' w-[403px] h-[317px] opacity-100 transform-none gap-x-[7.5em] gap-y-16 justify-around items-center p-16 px-[3.5em] flex relative transition-all duration-500 ease-in-out hover:bg-[#100f0fde] '>
                        {/*Des*/}
                        <div className='Description space-y-3'>
                        <div className='loc'>
                                <div className='opacity-100 block isolate'>
                                    <h5 className='opacity-100 transform-none text-[22px] font-light text-[#ffffffcc] leading-tight block isolate'>Grand City Arifwala Site Office</h5>
                                </div>
                            </div>
                            <div className='address'>
                            <p className='opacity-100 transform-none text-[18px] leading-inherit text-white/60 font-light block isolate'>4.1 km Pkpatan Road,Arifwala,Dist,Pakpatan</p>
                            </div>
                            <div className='timming'>
                            <p className='opacity-100 transform-none text-[18px] leading-inherit text-white/60  font-light block isolate'>MON-FRI: 9:00 AM - 6:00 PM</p>
                            </div>
                            <div className='emailNum'>
                                <a href='mailto:sales@pearlresidencia.com.pk' className='text-decoration-none text-[rgba(var(--bs-link-color-rgb),var(--bs-link-opacity,1))] cursor-pointer'>
                                <p className='opacity-100 transform-none text-sm leading-normal text-white/60   font-light block mb-2'>info@grandcity.pk</p>
                                </a>
                                <a href='tel:+92-304-111-2117' className='text-decoration-none text-[rgba(var(--bs-link-color-rgb),var(--bs-link-opacity,1))] cursor-pointer'>
                                <p className='opacity-100 transform-none text-sm leading-normal text-white/60   font-light block '>0330-271-4444</p>
                                </a>
                            </div>
                        </div>
                        {/*border Style*/}
                        <div className='border border-[#f1d04033] transition-colors duration-200 z-1 absolute inset-0 block'>
                        <div className='z-[10] mt-[-1px] ml-[-1px] absolute top-0 left-0 right-auto bottom-auto block bidi-isolate'>
                                    <div className='w-[5em] h-px bg-[#d9b751] absolute top-0 left-0 right-auto bottom-auto overflow-visible block bidi-isolate'></div>
                                    <div className='w-px h-[5em] bg-[#d9b751] absolute top-0 left-0 right-auto bottom-auto overflow-visible'></div>
                                </div>
                                <div className='z-10 mb-[-1px] mr-[-1px] absolute bottom-0 right-0 top-auto left-auto block'>
                                    <div className='absolute top-auto bottom-0 left-auto right-0 w-[1px] h-[5em] bg-[#d9b751] overflow-visible block bidi-isolate'></div>
                                    <div className='absolute top-auto bottom-0 left-auto right-0 w-[5em] h-[1px] bg-[#d9b751] overflow-visible block bidi-isolate'></div>
                                </div>
                        </div>
                        </div>
                    </div>
                </div>
            </section>
            {/*Section 3*/}
            <section className='relative block isolate bg-[#111010] borderGradeTopBtm'>

                    {/*Contact US Form*/}
                    <div className='w-full mx-auto max-w-[1313px] pt-[100px] pb-[100px] px-[20px]'>
                        {/*Heading Form*/}
                        <div className='flex justify-between flex-wrap -mt-0 -mr-[0.75rem] -ml-[0.75rem]'>
                            {/*Heading 1*/}
                            <div className='mb-0 flex-shrink-0 w-5/12'>
                            <div className='opacity-100 block'>
                                <h1 className='opacity-100 transform-none text-[65px] font-light text-[#ffffffcc] m-0 '>Contact Us for Expert Guidance</h1>
                            </div>
                            </div>
                            {/*Heading 2*/}
                            <div className='flex-shrink-0 flex-grow-0 basis-auto w-5/12'>
                                {/*title1*/}
                                <div className=' opacity-100'>
                                    <h4 className='opacity-100 transform-none text-[28px] font-light text-[#ffffffcc] m-0'>From property valuation to investment advice, we've got you covered.</h4>
                                </div>
                                {/*title2*/}
                                <div>
                                    <div className='opacity-100'>
                                    <h4 className='opacity-100 transform-none text-[28px] font-light text-[#959595] m-0 '>Explore our comprehensive range of services tailored to meet your unique needs. Excellence is just a click away!</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/*input Form*/}
                        <div className='mt-12 justify-between flex flex-wrap -mr-3 -ml-3'>
                            {/*Form 1*/}
                            <div className='mb-0 flex-shrink-0 w-5/12'>
                            <div className=''>
                                {/*link 1*/}
                                <a className='w-full gap-4 border-b border-white/20 text-white/40 no-underline grid grid-cols-[0.25fr_1fr_1fr] auto-cols-fr items-center py-[2vh] font-medium transition-[padding-right,color,border-color] duration-500 ease-out hover:pr-4 hover:text-white/60 hover:border-white/30' href='mailto:sales@pearlresidencia.com.pk'>
                                <div className='icon'>
                                    <i className='bi bi-pencil'></i>
                                </div>
                                <p className='opacity-100 transform-none text-[16px] leading-inherit text-white/80 m-0 transition-opacity duration-300 ease-in-out hover:opacity-80'>Email</p>
                                <div className='text-right'>
                                    <p className='opacity-100 transform-none text-[16px] leading-inherit text-white/80 m-0 transition-opacity duration-300 ease-in-out hover:opacity-80'>info@grandcity.com</p>
                                </div>
                                </a>
                                {/*link 2*/}
                                <a className='w-full gap-4 border-b border-white/20 text-white/40 no-underline grid grid-cols-[0.25fr_1fr_1fr] auto-cols-fr items-center py-[2vh] font-medium transition-[padding-right,color,border-color] duration-500 ease-out hover:pr-4 hover:text-white/60 hover:border-white/30' href='https://www.pearlresidencia.com.pk/tel:+92-304-111-2117'>
                                <div className='icon'>
                                    <i className='bi bi-pencil'></i>
                                </div>
                                <p className='opacity-100 transform-none text-[16px] leading-inherit text-white/80 m-0 transition-opacity duration-300 ease-in-out hover:opacity-80'>Phone</p>
                                <div className='text-right'>
                                    <p className='opacity-100 transform-none text-[16px] leading-inherit text-white/80 m-0 transition-opacity duration-300 ease-in-out hover:opacity-80'>0335-111-11-55</p>
                                </div>
                                </a>
                                {/*link 3*/}
                                <a className='w-full gap-4 border-b border-white/20 text-white/40 no-underline grid grid-cols-[0.25fr_1fr_1fr] auto-cols-fr items-center py-[2vh] font-medium transition-[padding-right,color,border-color] duration-500 ease-out hover:pr-4 hover:text-white/60 hover:border-white/30' href='https://www.google.com/maps/dir/31.4690594,74.3939224/pearl+residencia+toba+tek+singh+nearby/@31.4634663,72.1181625,8z/data=!3m1!4b1!4m9!4m8!1m1!4e1!1m5!1m1!1s0x39230f4cc1e10b61:0x1edc7bfbb634b164!2m2!1d72.4569153!2d31.0172993?entry=ttu&g_ep=EgoyMDI0MTExMC4wIKXMDSoASAFQAw%3D%3D'>
                                <div className='icon'>
                                    <i className='bi bi-pencil'></i>
                                </div>
                                <p className='opacity-100 transform-none text-[16px] leading-inherit text-white/80 m-0 transition-opacity duration-300 ease-in-out hover:opacity-80'>Direction</p>
                                <div className='text-right'>
                                    <p className='opacity-100 transform-none text-[16px] leading-inherit text-white/80 m-0 transition-opacity duration-300 ease-in-out hover:opacity-80'>DHA Phase-6 sector C, 170 Street 4 Lahore, Pakistan</p>
                                </div>
                                </a>
                                {/*link 4*/}
                                <a className='w-full gap-4 border-b border-white/20 text-white/40 no-underline grid grid-cols-[0.25fr_1fr_1fr] auto-cols-fr items-center py-[2vh] font-medium transition-[padding-right,color,border-color] duration-500 ease-out hover:pr-4 hover:text-white/60 hover:border-white/30' href='https://www.pearlresidencia.com.pk/contact-us#offices'>
                                <div className='icon'>
                                    <i className='bi bi-pencil'></i>
                                </div>
                                <p className='opacity-100 transform-none text-[16px] leading-inherit text-white/80 m-0 transition-opacity duration-300 ease-in-out hover:opacity-80 '>Offices</p>
                                <div className='text-right'>
                                    <p className='opacity-100 transform-none text-[16px] leading-inherit text-white/80 m-0 transition-opacity duration-300 ease-in-out hover:opacity-80 '>View All</p>
                                </div>
                                </a>
                            </div>
                            </div>
                            {/*Form2*/}
                            <div className='flex-shrink-0 flex-grow-0 w-5/12'>
                            <div className='contact-form-con '>
                                <form className='block mt-0 '>
                                    {/*input 1*/}
                                    <div className='flex justify-start items-center '>
                                       <label className='mb-0 text-[#ffffffcc] z-2 font-medium leading-tight absolute text-xl pointer-events-none inline-block cursor-default'>Full Name</label>
<input
  type='text'
   className=' outline-none z-[1] min-h-[4em] border-solid border-[1px] border-transparent border-b-[#f1d04080]  text-right bg-transparent
              py-4 pl-[10em] pr-0 text-xl font-normal transition-[min-height] duration-500 ease-[.075,.82,.165,1]
              relative rounded-none block w-full leading-[1.5] appearance-none bg-clip-padding'
  placeholder='Grand City'
//   name='name'
//   value='name'
/>
                                    </div>
                                     {/*input 2*/}
                                    <div className='flex justify-start items-center relative'>
                                       <label className='mb-0 text-[#ffffffcc] z-2 font-medium leading-tight absolute text-xl pointer-events-none inline-block cursor-default'>Email</label>
<input
  type='text'
  className=' outline-none z-[1] min-h-[4em] border-solid border-[1px] border-transparent border-b-[#f1d04080]  text-right bg-transparent
             py-4 pl-[10em] pr-0 text-xl text-white font-normal transition-[min-height] duration-500 ease-[.075,.82,.165,1]
             relative rounded-none block w-full leading-[1.5] appearance-none bg-clip-padding'
  placeholder='info@grandcity.pk'
  
/>
                                    </div>
                                    {/*input 3*/}
                                    <div className='flex justify-start items-center relative'>
                                       <label className='mb-0 text-[#ffffffcc] z-2 font-medium leading-tight absolute text-xl pointer-events-none inline-block cursor-default'>Phone Number</label>
<input
  type='text'
  className=' outline-none z-[1] min-h-[4em] border-solid border-[1px] border-transparent border-b-[#f1d04080]  text-right bg-transparent
             py-4 pl-[10em] pr-0 text-xl text-white font-normal transition-[min-height] duration-500 ease-[.075,.82,.165,1]
             relative rounded-none block w-full leading-[1.5] appearance-none bg-clip-padding'
  placeholder='0335-111-11-55'
 
/>
                                    </div>
                                    {/*input 4*/}
                                    <div className='flex justify-start items-center relative'>
                                       <label className='mb-0 text-[#ffffffcc] z-2 font-medium leading-tight absolute text-xl pointer-events-none inline-block cursor-default'>Area</label>
<input
  type='text'
  className=' outline-none z-[1] min-h-[4em] border-solid border-[1px] border-transparent border-b-[#f1d04080]  text-right bg-transparent
             py-4 pl-[10em] pr-0 text-xl text-white font-normal transition-[min-height] duration-500 ease-[.075,.82,.165,1]
             relative rounded-none block w-full leading-[1.5] appearance-none bg-clip-padding'
  placeholder='Location preference'
 
/>
                                    </div>
                                    {/*input 5*/}
                                    <div className='flex justify-start items-center relative'>
                                       <label className='mb-0 text-[#ffffffcc] z-2 font-medium leading-tight absolute text-xl pointer-events-none inline-block cursor-default'>Message</label>
<textarea
  className=' outline-none min-h-[8em] resize-none z-[1] border-solid border-[1px] border-transparent border-b-[#f1d04080]  text-right bg-transparent
             py-4 pl-[10em] pr-0 text-xl text-white font-normal transition-[min-height] duration-500 ease-[.075,.82,.165,1]
             relative rounded-none block w-full leading-[1.5] appearance-none bg-clip-padding'
  placeholder='Your ideas, dreams and requirements...'
  name='message'

/>
                                    </div>
                                    {/*Submit Button*/}
                                    <div className='flex justify-start items-center relative mt-3'>
                                        <div className='flex items-center relative min-w-[180px] min-h-[53px]'>
                                            <input
                                            type='submit'
                                            value='Submit'
                                            className='cursor-pointer border border-[#a86c03] text-white bg-[#d9b751] appearance-none absolute opacity-85 transition-all duration-200 ease-in-out flex items-center justify-center min-w-[180px] min-h-[53px] font-normal text-base leading-[1.3] capitalize hover:bg-[#c1a252] hover:border-[#b57603]'
                                            />
                                        </div>
                                    </div>
                                 
                                    
                                </form>
                            </div>
                            </div>
                        </div>
                    </div>

                    <div className='border border-[#f1d04033] transition-colors duration-200 z-1 absolute inset-0 block'>
                        <div className='z-[10] mt-[-1px] ml-[-1px] absolute top-0 left-0 right-auto bottom-auto block bidi-isolate'>
                                    <div className='w-[5em] h-px bg-[#d9b751] absolute top-0 left-0 right-auto bottom-auto overflow-visible block bidi-isolate'></div>
                                    <div className='w-px h-[5em] bg-[#d9b751] absolute top-0 left-0 right-auto bottom-auto overflow-visible'></div>
                                </div>
                                <div className='z-10 mb-[-1px] mr-[-1px] absolute bottom-0 right-0 top-auto left-auto block'>
                                    <div className='absolute top-auto bottom-0 left-auto right-0 w-[1px] h-[5em] bg-[#d9b751] overflow-visible block bidi-isolate'></div>
                                    <div className='absolute top-auto bottom-0 left-auto right-0 w-[5em] h-[1px] bg-[#d9b751] overflow-visible block bidi-isolate'></div>
                                </div>
                        </div>
            </section>
            {/*map*/}
            {/* <div className='map_con'>
                <div className='relative overflow-hidden h-[50vh] w-full'>
                    <div className='h-full w-full absolute top-0 left-0 bg-[#e5e3df]'>
                      
                    </div>
                </div>
            </div> */}
            <ContactInfo/>
        </main>
    </div>

    </div>
  )
}

export default page

