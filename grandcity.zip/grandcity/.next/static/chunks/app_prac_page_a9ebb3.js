(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_prac_page_a9ebb3.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_prac_page_a9ebb3.js",
  "chunks": [
    "static/chunks/app_prac_practice_b0e69a.css",
    "static/chunks/app_prac_page_3ed6b2.js"
  ],
  "source": "dynamic"
});
