(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_36ac26.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_36ac26.js",
  "chunks": [
    "static/chunks/app_4661c8._.css",
    "static/chunks/app_layout_d9f7ea.js"
  ],
  "source": "dynamic"
});
