(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_home_page_a9ebb3.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_home_page_a9ebb3.js",
  "chunks": [
    "static/chunks/app_home_custom_45a33c.css",
    "static/chunks/node_modules_next_dist_13e51f._.js",
    "static/chunks/node_modules_framer-motion_dist_es_3ddec1._.js",
    "static/chunks/app_home_page_92f4cf.js"
  ],
  "source": "dynamic"
});
