(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_a9ebb3.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_a9ebb3.js",
  "chunks": [
    "static/chunks/_c52b98._.js"
  ],
  "source": "dynamic"
});
