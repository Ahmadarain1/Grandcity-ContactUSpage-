import { motion } from "framer-motion";

export default function AboutBanner() {
  return (
    <section className="relative h-screen overflow-hidden bg-[#0a0f16]">
      {/* Video Background */}
      <video
        autoPlay
        loop
        muted
        className="absolute inset-0 w-full h-full object-cover"
        src="https://youtu.be/IS_Yj-mMTak" // Replace with your video URL
      />

      {/* Overlay */}
      <div className="absolute inset-0 bg-black bg-opacity-50 flex flex-col justify-center items-center text-center p-8">
        {/* Heading */}
        <motion.h1
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="text-white text-6xl md:text-7xl font-bold mb-4 leading-tight"
        >
          Your Trusted Real
          <br />
          Estate Advisors
        </motion.h1>

        {/* Subtext */}
        <motion.p
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
          className="text-gray-300 text-base md:text-lg max-w-2xl mt-4"
        >
          Lorem ipsum dolor sit amet, consectetur adipiscingDuis ut orci rutrum,
          aliquam purus vel, fermentum erat. Aenean elementum, tortor vitae
          sagittis tincidunt, magna urna consectetur erat.
        </motion.p>
      </div>
    </section>
  );
}
